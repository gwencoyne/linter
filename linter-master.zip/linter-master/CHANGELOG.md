## Upcoming

* Rewrite entire package
* Add support for Linter Messages v2
* Add support for Indie Providers v2
* Drop support for Indie Providers v1

## Pre v2.0

See the CHANGELOG for Pre v2.0 at [v1 CHANGELOG](https://github.com/steelbrain/linter/blob/v1/CHANGELOG.md)
